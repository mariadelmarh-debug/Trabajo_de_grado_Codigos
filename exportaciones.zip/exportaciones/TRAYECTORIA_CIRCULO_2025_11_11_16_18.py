import rclpy
from rclpy.node import Node
from frhal_msgs.srv import ROSCmdInterface
import time

class CommandClient(Node):
    def __init__(self):
        super().__init__("command_client")
        self.client = self.create_client(ROSCmdInterface, "/FR_ROS_API_service")
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("Service not available, waiting again...")

    def send_request_sync(self, command):
        req = ROSCmdInterface.Request()
        req.cmd_str = command
        future = self.client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)
        if future.done():
            try:
                response = future.result()
                return response.cmd_res
            except Exception as e:
                return None
        else:
            return None

def main(args=None):
    rclpy.init(args=args)
    command_client = CommandClient()
    commands = [
        'ResetAllError()',
        'CARTPoint(1,-6.500,491.000,530.000,167.000,54.000,-101.000)',
        'CARTPoint(2,-11.498,524.160,530.000,167.000,54.000,-101.000)',
        'CARTPoint(3,-26.048,554.374,530.000,167.000,54.000,-101.000)',
        'CARTPoint(4,-48.857,578.956,530.000,167.000,54.000,-101.000)',
        'CARTPoint(5,-77.899,595.723,530.000,167.000,54.000,-101.000)',
        'CARTPoint(6,-110.593,603.185,530.000,167.000,54.000,-101.000)',
        'CARTPoint(7,-144.034,600.679,530.000,167.000,54.000,-101.000)',
        'CARTPoint(8,-175.250,588.428,530.000,167.000,54.000,-101.000)',
        'CARTPoint(9,-201.468,567.519,530.000,167.000,54.000,-101.000)',
        'CARTPoint(10,-220.359,539.812,530.000,167.000,54.000,-101.000)',
        'CARTPoint(11,-230.243,507.767,530.000,167.000,54.000,-101.000)',
        'CARTPoint(12,-230.243,474.233,530.000,167.000,54.000,-101.000)',
        'CARTPoint(13,-220.359,442.188,530.000,167.000,54.000,-101.000)',
        'CARTPoint(14,-201.468,414.481,530.000,167.000,54.000,-101.000)',
        'CARTPoint(15,-175.250,393.572,530.000,167.000,54.000,-101.000)',
        'CARTPoint(16,-144.034,381.321,530.000,167.000,54.000,-101.000)',
        'CARTPoint(17,-110.593,378.815,530.000,167.000,54.000,-101.000)',
        'CARTPoint(18,-77.899,386.277,530.000,167.000,54.000,-101.000)',
        'CARTPoint(19,-48.857,403.044,530.000,167.000,54.000,-101.000)',
        'CARTPoint(20,-26.048,427.626,530.000,167.000,54.000,-101.000)',
        'CARTPoint(21,-11.498,457.840,530.000,167.000,54.000,-101.000)',
        'CARTPoint(22,-6.500,491.000,530.000,167.000,54.000,-101.000)',
        'MoveL(CART1,8)',
        'MoveL(CART2,8)',
        'MoveL(CART3,8)',
        'MoveL(CART4,8)',
        'MoveL(CART5,8)',
        'MoveL(CART6,8)',
        'MoveL(CART7,8)',
        'MoveL(CART8,8)',
        'MoveL(CART9,8)',
        'MoveL(CART10,8)',
        'MoveL(CART11,8)',
        'MoveL(CART12,8)',
        'MoveL(CART13,8)',
        'MoveL(CART14,8)',
        'MoveL(CART15,8)',
        'MoveL(CART16,8)',
        'MoveL(CART17,8)',
        'MoveL(CART18,8)',
        'MoveL(CART19,8)',
        'MoveL(CART20,8)',
        'MoveL(CART21,8)',
        'MoveL(CART22,8)',
    ]

    success_count = 0
    error_count = 0

    for i, command in enumerate(commands, 1):
        result = command_client.send_request_sync(command)
        if result is not None:
            if result == 1 or result == 0:
                success_count += 1
            else:
                error_count += 1
        else:
            error_count += 1
        time.sleep(0.1)

    command_client.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
